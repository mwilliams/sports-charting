require 'test/unit'
require 'team'
require 'rubygems'
require 'xmlsimple'
require 'net/http'

class TeamUnitTest < Test::Unit::TestCase
  # All tests are using ID's of a known game ID that is good as of
  # May 19th, 2008
  
  def test_get_teams_for_sport
    assert true
  end
  
end
